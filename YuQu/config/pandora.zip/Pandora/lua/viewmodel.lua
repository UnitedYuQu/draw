-- Sets variable viewmodel_offset_x to the cvar
local viewmodel_offset_x = cvar.find_var("viewmodel_offset_x")
-- Sets variable viewmodel_offset_y to the cvar
local viewmodel_offset_y = cvar.find_var("viewmodel_offset_y")
-- Sets variable viewmodel_offset_z to the cvar
local viewmodel_offset_z = cvar.find_var("viewmodel_offset_z")

-- Adds label for showing where Override Viewmodel FOV is located becasue I cba to make a slider for it 
local label1 = ui.add_label("- Viewmodel FOV is located in - \nVisuals -> Other ESP -> \nOverride Viewmodel FOV")
-- Adds X slider to change "viewmodel_offset_x" cvar
local offset_x = ui.add_slider("Offset X", -20, 20)
-- Sets a default value for "viewmodel_offset_x"
offset_x:set(2)
-- Adds Y slider to change "viewmodel_offset_y" cvar
local offset_y = ui.add_slider("Offset Y", -20, 20)
-- Sets a default value for "viewmodel_offset_y"
offset_y:set(2)
-- Adds Z slider to change "viewmodel_offset_z" cvar
local offset_z = ui.add_slider("Offset Z", -20, 20)
-- Sets a default value for "viewmodel_offset_z"
offset_z:set(-2)

-- Adds note label
local label = ui.add_label("Note: When you unload the lua, \nyour viewmodel will not reset!")

-- Starts function
callbacks.register("paint", function()

    -- Sets "viewmodel_offset_x" cvar to slider created above
    viewmodel_offset_x:set_value_float(offset_x:get())
    -- Sets "viewmodel_offset_y" cvar to slider created above
    viewmodel_offset_y:set_value_float(offset_y:get())
    -- Sets "viewmodel_offset_z" cvar to slider created above
    viewmodel_offset_z:set_value_float(offset_z:get())

end)