local desam = ui.get("Rage", "Anti-aim", "Fake anti-aim", "Desync amount")
local save = desam:get()
ui.add_label("Low delta on Slow motion")
local hotkey_item = ui.add_hotkey("Low delta")
local slider_item = ui.add_slider("New Desync Amount", 0, 60)
local function draw()
	if hotkey_item:get() == true then
		desam:set(slider_item:get())
	else
		desam:set(save)
	end
end
callbacks.register("paint", draw)