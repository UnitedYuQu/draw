local desync_amount = ui.get("Rage", "Anti-aim", "Fake anti-aim", "Desync amount")
	

local inverted_desync_amount = ui.get("Rage", "Anti-aim", "Fake anti-aim", "Inverted desync amount")
local inverted_desync_amount_value = inverted_desync_amount:get() -- returns true/false

callbacks.register("paint", function()
     
    local random = math.random(60)

if not anti_aim.inverted()

   then desync_amount:set(random)

	end

if anti_aim.inverted()

   then inverted_desync_amount:set(random)

	end

end)