local killsay = ui.add_checkbox("enable killsay")

function on_player_death(event)
    -- Checks if killsay checkbox is enabled, if not return
    if not killsay:get()then
        return
    end
    -- Get user ID and attacker information for killsay
    userid = event:get_int("userid")
    attacker = event:get_int("attacker")

    attacker_index = engine.get_player_for_user_id(attacker)
    noob_index = engine.get_player_for_user_id(userid)

    local_player_index = engine.get_local_player()


    if attacker_index == local_player_index and noob_index ~= local_player_index then
        engine.execute_client_cmd("insert text here")
    end

end