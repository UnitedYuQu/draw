--pCodenZ



local slider = ui.add_slider("Zoom Time", 3, 20)

function on_player_death(event)
    local local_player = entity_list.get_client_entity(engine.get_local_player())

    if local_player == nil then
        return
    end

    local attacker = engine.get_player_for_user_id(event:get_int("attacker"))

    if attacker == engine.get_local_player() then
        local_player:get_prop("DT_CSPlayer", "m_flHealthShotBoostExpirationTime"):set_float(global_vars.curtime + (slider:get() * 0.1))
    end
end

callbacks.register("player_death", on_player_death)