-- menu shit
local toggleOn = ui.add_checkbox("enable this godlike lua")
--
local colPicker = ui.add_colorpicker("lmao")
colPicker:set(color.new(225, 225, 225))
--
local timeSlider = ui.add_slider("time in ticks", 16, 512)
timeSlider:set(128)
--
local numberOfOnes = ui.add_slider("amount of oneness", 1, 100)
numberOfOnes:set(5)
-- locals
local oneList = { }



function player_hurt(e)
  if not toggleOn then return end

  local attacker = engine.get_player_for_user_id(e:get_int("attacker", 0))
  local userHit = engine.get_player_for_user_id(e:get_int("userid", 0))
  local damageDealt = e:get_float("dmg_health", 0)
  local userHitHP = e:get_float("health", 0)
  local headPos = entity_list.get_client_entity(userHit):get_prop("DT_BaseEntity", "m_vecOrigin"):get_vector()

  if engine.get_local_player() == attacker then     -- if the attacker is u
    if damageDealt >= 100 and userHitHP <= 0 then   -- and if damage over 100 AND health 0 (fuck people who have 105 health in servers)
      for i = 1, numberOfOnes:get(), 1 do
        local num = math.floor(timeSlider:get()/4)  -- V V V 
        local offset = math.random(0, num)          -- random time offset (slightly different speed and fade out time)
        local headPos = vector.new(headPos.x + math.random(-10, 10), headPos.y + math.random(-10, 10), headPos.z + math.random(-20, 20))

        time = global_vars.tickcount + (timeSlider:get() + offset)
        table.insert(oneList, {headPos, time, offset})  -- insert position, time for how long the "1" will be up + the offset because im retarded
      end
    end
  end
end

function on_paint()
  local toggleOn = toggleOn:get()
  if not toggleOn then return end

  local r, g, b = colPicker:get():r(), colPicker:get():g(), colPicker:get():b()

  for i, v in ipairs(oneList) do -- list thru the list (ikr wow)
    if v[1] ~= nil then
      if v[2] > global_vars.tickcount then  -- as long as the time var from the table is over cur tickcount we draw [1/2]

        local finalPos_ = vector2d.new(0,0) 

        local perc = (v[2] - global_vars.tickcount) * (100 / (timeSlider:get() + v[3])) -- i dont remember how i did this
        local finalPosition = vector.new(v[1].x, v[1].y, v[1].z + 80 - (perc*0.6))

        render.world_to_screen(finalPosition, finalPos_)

        render.text(finalPos_.x, finalPos_.y, "1", color.new(r,g,b, 255 * perc/100))
      else                                  
        table.remove(oneList, i)            -- else remove from table [2/2]
      end
    end
  end
end

callbacks.register("player_hurt", player_hurt)
callbacks.register("paint", on_paint)

--Much love from fur <3
--thanks to andosa for reminding me how to do the most basic stuff