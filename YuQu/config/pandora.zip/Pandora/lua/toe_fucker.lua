
local slide = ui.get("Misc", "General", "Movement", "Slide walk")
callbacks.register("paint", function()     
    local rand = math.random(100)      
    local percentage = 35
    slide:set(rand <= (100*(percentage/100)))
end)