local font = render.create_font("WeaponIcons", 26, 500, 16|128) 

function on_paint()   
    local_player = entity_list.get_client_entity(engine.get_local_player())

    if not engine.in_game() then
        return
    end

    if local_player == nil then 
        return
    end
    
    if local_player:get_prop("DT_BasePlayer", "m_iHealth"):get_int() <= 0 then
        return
    end

    local screen_size_x, screen_size_y = render.get_screen()
    local screen_center = vector2d.new(screen_size_x / 2, screen_size_y / 2)

    local c = color.new(255,255,255)
    if penetration.damage() > 0 then
        c = color.new(0,255,0,220)
    end

    render.rectangle_filled(screen_center.x - 2, screen_center.y - 2, 5, 5, color.new(0,0,0,180))
    render.rectangle_filled(screen_center.x - 1, screen_center.y - 1, 3, 3, c)

    font:text(screen_center.x, screen_center.y, c, "abcdefghijklmnop", 0)
end

callbacks.register("paint", on_paint)