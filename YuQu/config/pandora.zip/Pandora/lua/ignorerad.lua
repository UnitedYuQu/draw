callbacks.register("player_connect_full", function(event)
    if engine.get_player_for_user_id(event:get_int("userid")) == engine.get_local_player() then
        engine.execute_client_cmd("ignorerad")
    end
end)

-- sat made this probably