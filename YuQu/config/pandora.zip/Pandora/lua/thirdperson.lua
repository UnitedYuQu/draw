local entity_get_client_entity = entity_list.get_client_entity

local thirdperson_slider = ui.add_slider("Thirdperson distance", 0, 250)
thirdperson_slider:set(150)

local thirdperson = ui.get("Visuals", "Other", "Effects", "Thirdperson")
local thirdperson_key = ui.get("Visuals", "Other", "Effects", "Thirdperson key")
local thirdperson_dist = ui.get("Visuals", "Other", "Effects", "Distance")

local distance = 0

-- maybe do this in a different function, this is just an example though
function on_paint()
    -- Get screen size to render in the middle
    local screen_width, screen_height = render.get_screen()
    local scx, scy = screen_width * 0.5, screen_height * 0.5
 
    -- Local player check
    local_player = entity_get_client_entity(engine.get_local_player())
 
    -- Checks to see if client is in game, else return
    if not engine.in_game() then
        return
    end
 
    -- Local player check to see if local player is a thing
    if local_player == nil then 
        return
    end
     
    -- Health check to see if you are alive
    if local_player:get_prop("DT_BasePlayer", "m_iHealth"):get_int() <= 0 then
        return
    end

    -- Reach full alpha in ~100ms
    local multiplier = (1.0 / 0.2) * global_vars.frametime

    -- Health check to see if you are alive
    if thirdperson_key:get() then
        if distance < 1.0 then
            distance = ( distance + ( multiplier * ( 1 - distance ) ) )
        end
    else
        distance = 0
    end

    -- clamp alpha not to go out of bounds
    if distance >= 1.0 then
        distance = 1
    end

    if thirdperson:get() then
        thirdperson_dist:set(thirdperson_slider:get() * distance)
    end
    --thirdperson_slider
end

callbacks.register("paint", on_paint)