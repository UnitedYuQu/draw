local glow_color = ui.get("Visuals", "Models", "Local", "Desync chams color")

local label = ui.add_label("Desync pulse color")
local clr = ui.add_colorpicker("Desync pulse color")
clr:set(glow_color:get())

function on_paint() 
    local alpha = math.floor(math.sin(global_vars.realtime * 2) * 127.5 + 127.5)

    local r, g, b, a = clr:get():r(), clr:get():g(), clr:get():b(), clr:get():a()
    
    glow_color:set(color.new(r,g,b,a*(alpha/255)))
end

callbacks.register("paint", on_paint)