local OldChoke = 0
local toDraw2 = 0
local toDraw1 = 0
local toDraw0 = 0

function on_paint()
	render.add_indicator(string.format('%i-%i-%i',toDraw2,toDraw1,toDraw0))

	if client.choked_commands() < OldChoke then --sent
		toDraw0 = toDraw1
		toDraw1 = toDraw2
		toDraw2 = OldChoke
	end
	
	OldChoke = client.choked_commands()
end

callbacks.register("paint", on_paint)