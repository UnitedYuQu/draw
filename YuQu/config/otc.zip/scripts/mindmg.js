UI.AddCheckbox("Enable");
UI.AddCheckbox("Show currently mindamage");
UI.AddHotkey("Minimum Damage Override");
UI.AddSliderInt("General Mindmg", 0, 130);
UI.AddSliderInt("Pistol Mindmg", 0, 130);
UI.AddSliderInt("Heavy Pistol Mindmg", 0, 130);
UI.AddSliderInt("Scout Mindmg", 0, 130);
UI.AddSliderInt("AWP Mindmg", 0, 130);
UI.AddSliderInt("Auto Mindmg", 0, 130);

// auto
setDMG_auto = false
setDMG_auto_return = true
// awp
setDMG_awp = false
setDMG_awp_return = true
// scout
setDMG_scout = false
setDMG_scout_return = true
// heavy pistol
setDMG_HVpistol = false
setDMG_HVpistol_return = true
// pistol
setDMG_pistol = false
setDMG_pistol_return = true
// general
setDMG_general = false
setDMG_general_return = true

function SetEnabled()
{

    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable"))
	{
		UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Show currently mindamage", 1);
		UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override", 1);
		UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "General Mindmg", 1);
	    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pistol Mindmg", 1);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Heavy Pistol Mindmg", 1);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Scout Mindmg", 1);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "AWP Mindmg", 1);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Auto Mindmg", 1);
	}
	else
	{
		UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Show currently mindamage", 0);
		UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Minimum Damage Override", 0);
		UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "General Mindmg", 0);
	    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Pistol Mindmg", 0);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Heavy Pistol Mindmg", 0);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Scout Mindmg", 0);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "AWP Mindmg", 0);
        UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "Auto Mindmg", 0);
    }
}

function isActive(a)
{
    return UI.IsHotkeyActive("Script items", a)
}
function setValue(cat, value)
{
    UI.SetValue("Rage", cat.toUpperCase(), "Targeting", "Minimum damage", value)
}


function isHeavyPistol(name)
{
    if (name == "r8 revolver" || name == "desert eagle")
    {
        return true
    }
}

function isPistol(name)
{
    if (name == "glock 18" || name == "five seven" || name == "dual berettas" || name == "p250" || name == "tec 9" || name == "usp s" || name == "cz75 auto" || name == "p2000")
    {
        return true
    }
}

function isAutoSniper(name)
{
    if(name == "scar 20" || name == "g3sg1")
    {
        return true
    }
}

function onCM()
{
	var general_value = UI.GetValue("Script items", "General Mindmg")
	var pistol_value = UI.GetValue("Script items", "Pistol Mindmg")
	var heavy_value = UI.GetValue("Script items", "Heavy Pistol Mindmg")
    var scout_value = UI.GetValue("Script items", "Scout Mindmg")
    var awp_value = UI.GetValue("Script items", "AWP Mindmg")
    var auto_value = UI.GetValue("Script items", "Auto Mindmg")
	local_weapon_name =  Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))

	// GENERAL

        if (isActive("Minimum Damage Override"))
        {
			if (!setDMG_general)
			{
			   general_cache = UI.GetValue("Rage", "GENERAL", "Targeting", "Minimum damage")
			   setValue("GENERAL", general_value)
			   setDMG_general = true
               setDMG_general_return = false
			}
        }
        else
	    {
			if (!setDMG_general_return)
			{
		       setValue("GENERAL", general_cache)
		       setDMG_general = false
               setDMG_general_return = true
			}
		}	

	// PISTOL

	if (isPistol(local_weapon_name))
	{
        if (isActive("Minimum Damage Override"))
        {
			if (!setDMG_pistol)
			{
			   pistol_cache = UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage")
			   setValue("PISTOL", pistol_value)
			   setDMG_pistol = true
               setDMG_pistol_return = false
			}
        }
        else
	    {
			if (!setDMG_pistol_return)
			{
		       setValue("PISTOL", pistol_cache)
		       setDMG_pistol = false
               setDMG_pistol_return = true
			}
		}
	}

	// HEAVY PISTOL

	if (isHeavyPistol(local_weapon_name))
	{
        if (isActive("Minimum Damage Override"))
        {
			if (!setDMG_HVpistol)
			{
			   HVpistol_cache = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
			   setValue("HEAVY PISTOL", heavy_value)
			   setDMG_HVpistol = true
               setDMG_HVpistol_return = false
			}
        }
        else
	    {
			if (!setDMG_HVpistol_return)
			{
		       setValue("HEAVY PISTOL", HVpistol_cache)
		       setDMG_HVpistol = false
               setDMG_HVpistol_return = true
			}
		}
	}

	// SCOUT

	if (local_weapon_name == "ssg 08")
	{
        if (isActive("Minimum Damage Override"))
        {
			if (!setDMG_scout)
			{
			   scout_cache = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
			   setValue("SCOUT", scout_value)
			   setDMG_scout = true
               setDMG_scout_return = false
			}
        }
        else
	    {
			if (!setDMG_scout_return)
			{
		       setValue("SCOUT", scout_cache)
		       setDMG_scout = false
               setDMG_scout_return = true
			}
		}
	}

	// AWP

	if (local_weapon_name == "awp")
	{
        if (isActive("Minimum Damage Override"))
        {
			if (!setDMG_awp)
			{
			   awp_cache = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
			   setValue("AWP", awp_value)
			   setDMG_awp = true
               setDMG_awp_return = false
			}
        }
        else
	    {
			if (!setDMG_awp_return)
			{
		       setValue("AWP", awp_cache)
		       setDMG_awp = false
               setDMG_awp_return = true
			}
		}
	}

	// AUTO

	if (isAutoSniper(local_weapon_name))
	{
        if (isActive("Minimum Damage Override"))
        {
			if (!setDMG_auto)
			{
			   auto_cache = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
			   setValue("AUTOSNIPER", auto_value)
			   setDMG_auto = true
               setDMG_auto_return = false
			}
        }
        else
	    {
			if (!setDMG_auto_return)
			{
		       setValue("AUTOSNIPER", auto_cache)
		       setDMG_auto = false
               setDMG_auto_return = true
			}
		}
	}
}

function indicator()
{
    render_get_screen_size = Render.GetScreenSize
    const y = render_get_screen_size()[1];
	wep = Entity.GetName(Entity.GetWeapon(Entity.GetLocalPlayer()))
	general = UI.GetValue("Rage", "GENERAL", "Targeting", "Minimum damage")
	pistol = UI.GetValue("Rage", "PISTOL", "Targeting", "Minimum damage")
    heavy = UI.GetValue("Rage", "HEAVY PISTOL", "Targeting", "Minimum damage")
    scout = UI.GetValue("Rage", "SCOUT", "Targeting", "Minimum damage")
    awp = UI.GetValue("Rage", "AWP", "Targeting", "Minimum damage")
    auto = UI.GetValue("Rage", "AUTOSNIPER", "Targeting", "Minimum damage")
	font = Render.AddFont("Verdana", 18, 700);

    var str = ""
    if (UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Enable") && UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Show currently mindamage") && Entity.IsValid(Entity.GetLocalPlayer()) && Entity.IsAlive(Entity.GetLocalPlayer()))
    {
		if (isPistol(wep))
        {
            str = pistol
        }
        else if (isHeavyPistol(wep))
        {
            str = heavy
        }
        else if(wep == "ssg 08")
        {
            str = scout
        }
        else if(wep == "awp")
        {
            str = awp
        }
        else if (isAutoSniper(wep))
        {
            str = auto
        }
		else
		{
			str = general
		}
    }
         Render.StringCustom(18, y - 312, 0, str+"", [ 0, 0, 0, 255 ], font);
         Render.StringCustom(17, y - 312, 0, str+"", [255,255,255,255], font)
}

Global.RegisterCallback("Draw", "SetEnabled");
Cheat.RegisterCallback("CreateMove", "onCM");
Cheat.RegisterCallback("Draw", "indicator");