local function createmove()
	if cmd.get_button_state(buttons.in_use) then
		menu.set_int("Antiaim.antiaim_type", 1)
	else
		menu.set_int("Antiaim.antiaim_type", 0)
	end
end

client.add_callback("on_createmove", createmove)

